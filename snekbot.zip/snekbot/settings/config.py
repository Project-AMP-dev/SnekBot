DISCORD = {
    'token': 'NTg2MDkxMjE1ODA0NDMyMzg0.XPjMkw.7f1KZ4sWpQ-K1bnyinXKIj87Vog'
}

MODERATION = {
    'default_clear_value':5,
    'max_clear_value': 100,
    'default_kick_reason': 'Inappropriate behaviour.:expressionless:',
    'default_ban_reason': 'Inappropriate behaviour.:expressionless:',   
}

FUN = {
    'responses':[   'It is certain.',
                    'It is decidedly so.',
                    'Without a doubt.',
                    'Yes - definitely.',
                    'You may rely on it.',
                    'As I see it, yes.',
                    'Most likely.',
                    'Outlook good.',
                    'Yes.',
                    'Signs point to yes.',
                    'Reply hazy, try again.',
                    'Ask again later.',
                    'Better not tell you now.',
                    'Cannot predict now.',
                    'Concentrate and ask again.',
                    'Don\'t count on it.',
                    'My reply is no.',
                    'My sources say no.',
                    'Outlook not so good.',
                    'Very doubtful.'
                ]
}

EVENTS = {
    'status' : ['Fisting Iron Fist', 'with girls', 'with snek', 'with lord', '♪  Flute for snek  ♪']
}
